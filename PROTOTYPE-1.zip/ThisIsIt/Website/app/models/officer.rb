class Officer < ApplicationRecord
end
