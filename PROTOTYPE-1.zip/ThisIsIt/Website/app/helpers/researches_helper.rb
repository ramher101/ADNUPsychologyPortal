module ResearchesHelper
end
