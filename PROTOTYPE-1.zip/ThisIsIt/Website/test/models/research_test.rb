require 'test_helper'

class ResearchTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
